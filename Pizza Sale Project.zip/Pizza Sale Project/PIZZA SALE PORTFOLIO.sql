create database Pizza_DB

SELECT * 
FROM Pizza_DB..pizza_sales

--Total revenue(total price of all the pizzas)
SELECT SUM(total_price) AS Total_Revenue
FROM Pizza_DB..pizza_sales

-- Determine average order value
SELECT  SUM(total_price)/COUNT(DISTINCT order_id) AS AVG_Order_Value
FROM Pizza_DB..pizza_sales

--Total pizzas sold
SELECT SUM(quantity) AS TotalPizza_Sold
FROM Pizza_DB..pizza_sales

--Total orders placed
SELECT COUNT(DISTINCT order_id) AS Total_Orders
FROM Pizza_DB..pizza_sales

--Average pizzas per order(
SELECT CAST(CAST(SUM(quantity) AS DECIMAL(10,2))/ 
CAST(COUNT(DISTINCT order_id) AS DECIMAL(10,2)) AS DECIMAL(10,2)) AS AVG_PizzaPerOrder 
FROM Pizza_DB..pizza_sales


--Daily trend for orders. Get output for all the days in the week on how many orders placed
--Datename is an argument used to derive the dasy of week and DW(Day of Week) used as a character.
SELECT DATENAME(DW, order_date) AS order_date, COUNT(DISTINCT order_id) AS Total_ordersPerDay
FROM Pizza_DB..pizza_sales
GROUP BY DATENAME(DW, order_date) 

--Hourly trend of orders
SELECT DATEPART(HOUR, order_time) AS OrderHours , COUNT(DISTINCT order_id) AS Total_orders
FROM Pizza_DB..pizza_sales
GROUP BY DATEPART(HOUR, order_time)
ORDER BY DATEPART(HOUR, order_time)

--Percentage of sales by pizza cetgory
SELECT pizza_category, SUM(total_price) AS Total_Sales, SUM(total_price) * 100 / (SELECT SUM(total_price) FROM Pizza_DB..pizza_sales WHERE MONTH(order_date) = 1) AS PercentageOfSales
FROM Pizza_DB..pizza_sales
WHERE MONTH(order_date) = 1 --seeing for month of january
GROUP BY pizza_category

--Percentage of sales by Pizza size
SELECT pizza_size, CAST(SUM(total_price) AS DECIMAL(10,2)) AS Total_Sales, CAST(SUM(total_price) * 100 / (SELECT SUM(total_price) FROM Pizza_DB..pizza_sales) AS DECIMAL(10,2)) AS PercentageOfSales
FROM Pizza_DB..pizza_sales
GROUP BY pizza_size
ORDER BY PercentageOfSales DESC

--Total Pizza sold per cstegory
SELECT pizza_category, SUM(quantity) AS TotalPizzaSold
FROM Pizza_DB..pizza_sales
GROUP BY pizza_category

--TOP 5 BEST SELLERS
SELECT TOP 5 pizza_name, SUM(quantity) AS TotalPizzaSold
FROM Pizza_DB..pizza_sales
GROUP BY pizza_name
ORDER BY SUM(quantity) DESC

--TOP 5 WORST SELLERS
SELECT TOP 5 pizza_name, SUM(quantity) AS TotalPizzaSold
FROM Pizza_DB..pizza_sales
WHERE MONTH(order_date) = 5 --check for May
GROUP BY pizza_name
ORDER BY SUM(quantity)